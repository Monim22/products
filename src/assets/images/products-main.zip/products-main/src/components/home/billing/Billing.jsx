import React from 'react'

function Billing() {
  return (
    <div>Billing</div>
  )
}

export default Billing