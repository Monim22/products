import React from 'react'

function GroupProducts() {
  return (
    <div>GroupProducts</div>
  )
}

export default GroupProducts