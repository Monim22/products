import React from 'react'

function Clients() {
  return (
    <div>Clients</div>
  )
}

export default Clients