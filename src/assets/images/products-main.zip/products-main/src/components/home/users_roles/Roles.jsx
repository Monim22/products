import React from 'react'

function Roles() {
  return (
    <div>Roles</div>
  )
}

export default Roles