import React from "react";

function CompanyProfile() {
  return <div>CompanyProfile</div>;
}

export default CompanyProfile;
