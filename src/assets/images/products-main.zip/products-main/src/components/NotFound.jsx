import React from "react";

function NotFound() {
  return <div className="text-red-700 font-bold">404 Not Found</div>;
}

export default NotFound;
